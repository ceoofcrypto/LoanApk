import { Home, PlusCircle, List } from "lucide-react"
import { Button } from "@/components/ui/button"

type BottomNavigationProps = {
  currentPage: string
  onChangePage: (page: string) => void
}

export function BottomNavigation({ currentPage, onChangePage }: BottomNavigationProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center h-16">
      <Button
        variant={currentPage === "manage" ? "default" : "ghost"}
        size="icon"
        onClick={() => onChangePage("manage")}
      >
        <List className="h-6 w-6" />
      </Button>
      <Button variant={currentPage === "home" ? "default" : "ghost"} size="icon" onClick={() => onChangePage("home")}>
        <Home className="h-6 w-6" />
      </Button>
      <Button variant={currentPage === "new" ? "default" : "ghost"} size="icon" onClick={() => onChangePage("new")}>
        <PlusCircle className="h-6 w-6" />
      </Button>
    </div>
  )
}

