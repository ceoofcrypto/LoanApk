import { CreditCard } from "lucide-react"

export function DashboardHeader() {
  return (
    <header className="bg-[#2563EB] text-white py-4">
      <div className="container mx-auto px-4 flex items-center">
        <CreditCard className="h-6 w-6 mr-2" />
        <h1 className="text-2xl font-bold">KLOAN</h1>
      </div>
    </header>
  )
}

