export function DeveloperCredit() {
  return (
    <div className="text-center text-sm text-gray-500 dark:text-gray-400 mt-8 pb-4">
      <p>BHGWN</p>
      <p>
        <a
          href="https://www.facebook.com/iamkisny"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:underline"
        >
          www.facebook.com/iamkisny
        </a>
      </p>
    </div>
  )
}

