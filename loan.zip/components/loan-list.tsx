"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { SearchBar } from "@/components/search-bar"
import { Edit2, Trash2, CheckCircle, FileText } from "lucide-react"

type Loan = {
  id: number
  borrowerName: string
  amount: number
  interest: number
  status: "pending" | "collected"
  notes?: string
  loanDate: string
}

export function LoanList({
  loans,
  onMarkAsCollected,
  onDelete,
  onEdit,
  isManageSection = false,
}: {
  loans: Loan[]
  onMarkAsCollected: (id: number) => void
  onDelete: (id: number) => void
  onEdit: (id: number, newAmount: number) => void
  isManageSection?: boolean
}) {
  const [searchQuery, setSearchQuery] = useState("")
  const [editingLoan, setEditingLoan] = useState<number | null>(null)
  const [editAmount, setEditAmount] = useState<string>("")

  const filteredLoans = loans.filter((loan) => loan.borrowerName.toLowerCase().includes(searchQuery.toLowerCase()))

  const handleEdit = (id: number) => {
    const loan = loans.find((loan) => loan.id === id)
    if (loan) {
      setEditingLoan(id)
      setEditAmount(loan.amount.toString())
    }
  }

  const handleSaveEdit = (id: number) => {
    const newAmount = Number.parseFloat(editAmount)
    if (!isNaN(newAmount) && newAmount >= 0) {
      onEdit(id, newAmount)
      setEditingLoan(null)
      setEditAmount("")
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-medium">Loan List</CardTitle>
      </CardHeader>
      <CardContent>
        {isManageSection && <SearchBar onSearch={setSearchQuery} />}
        <Tabs defaultValue="to-collect" className="mt-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="to-collect">To Collect</TabsTrigger>
            <TabsTrigger value="collected">Collected</TabsTrigger>
          </TabsList>
          <TabsContent value="to-collect">
            <LoanCards
              loans={filteredLoans.filter((loan) => loan.status === "pending")}
              onMarkAsCollected={onMarkAsCollected}
              onDelete={onDelete}
              onEdit={handleEdit}
              editingLoan={editingLoan}
              editAmount={editAmount}
              setEditAmount={setEditAmount}
              handleSaveEdit={handleSaveEdit}
              isManageSection={isManageSection}
            />
          </TabsContent>
          <TabsContent value="collected">
            <LoanCards
              loans={filteredLoans.filter((loan) => loan.status === "collected")}
              onDelete={onDelete}
              isManageSection={isManageSection}
            />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

function LoanCards({
  loans,
  onMarkAsCollected,
  onDelete,
  onEdit,
  editingLoan,
  editAmount,
  setEditAmount,
  handleSaveEdit,
  isManageSection,
}: {
  loans: Loan[]
  onMarkAsCollected?: (id: number) => void
  onDelete?: (id: number) => void
  onEdit?: (id: number) => void
  editingLoan?: number | null
  editAmount?: string
  setEditAmount?: (value: string) => void
  handleSaveEdit?: (id: number) => void
  isManageSection: boolean
}) {
  return (
    <div className="space-y-4 mt-4">
      {loans.map((loan) => (
        <Card
          key={loan.id}
          className="border-l-4 border-l-yellow-500 dark:border-l-yellow-600 bg-white dark:bg-gray-800"
        >
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold">{loan.borrowerName}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Amount: NPR {loan.amount.toLocaleString()}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Loan Date: {new Date(loan.loanDate).toLocaleDateString()}
                </p>
                {isManageSection && (
                  <p className="text-sm text-gray-600 dark:text-gray-400">Interest: {loan.interest}%</p>
                )}
                {loan.notes && (
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-2 flex items-center">
                    <FileText className="h-4 w-4 mr-1" />
                    {loan.notes}
                  </p>
                )}
              </div>
              {isManageSection && (
                <div className="flex items-center space-x-2">
                  {editingLoan === loan.id ? (
                    <>
                      <Input
                        type="number"
                        value={editAmount}
                        onChange={(e) => setEditAmount?.(e.target.value)}
                        className="w-24 h-8 text-sm"
                      />
                      <Button size="sm" className="h-8 px-2 text-xs" onClick={() => handleSaveEdit?.(loan.id)}>
                        Save
                      </Button>
                    </>
                  ) : (
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => onEdit?.(loan.id)}>
                      <Edit2 className="h-4 w-4" />
                    </Button>
                  )}
                  {loan.status === "pending" && onMarkAsCollected && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 w-8 p-0"
                      onClick={() => onMarkAsCollected(loan.id)}
                    >
                      <CheckCircle className="h-4 w-4" />
                    </Button>
                  )}
                  {onDelete && (
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => onDelete(loan.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

