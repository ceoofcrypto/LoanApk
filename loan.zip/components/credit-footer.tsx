export function CreditFooter() {
  return (
    <footer className="fixed bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white py-2 text-center text-sm">
      <a href="https://www.facebook.com/iamkisny" target="_blank" rel="noopener noreferrer" className="hover:underline">
        www.facebook.com/iamkisny
      </a>
    </footer>
  )
}

