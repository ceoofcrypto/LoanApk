"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts"

type Loan = {
  id: number
  borrowerName: string
  amount: number
  interest: number
  status: "pending" | "collected"
}

export function LoanMetrics({ loans }: { loans: Loan[] }) {
  const totalLoans = loans.reduce((sum, loan) => sum + loan.amount, 0)
  const collectedAmount = loans
    .filter((loan) => loan.status === "collected")
    .reduce((sum, loan) => sum + loan.amount, 0)
  const remainingBalance = totalLoans - collectedAmount

  const data = [
    { name: "Collected", value: collectedAmount },
    { name: "Pending", value: remainingBalance },
  ]

  const COLORS = ["#FFD700", "#4CAF50"] // Gold for collected, Green for pending

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium">Loan Collection Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <MetricCard title="Total Loans" value={`NPR ${totalLoans.toLocaleString()}`} color="bg-blue-500" />
        <MetricCard title="Collected" value={`NPR ${collectedAmount.toLocaleString()}`} color="bg-yellow-500" />
        <MetricCard title="Remaining" value={`NPR ${remainingBalance.toLocaleString()}`} color="bg-green-500" />
      </div>
    </div>
  )
}

function MetricCard({ title, value, color }: { title: string; value: string; color: string }) {
  return (
    <Card className="overflow-hidden">
      <CardHeader className={`${color} text-white py-2`}>
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent className="p-2 bg-gradient-to-r from-yellow-100 to-green-100 dark:from-yellow-800 dark:to-green-800">
        <p className="text-lg font-bold truncate">{value}</p>
      </CardContent>
    </Card>
  )
}

