"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

type Loan = {
  id: number
  borrowerName: string
  amount: number
  interestRate: number
  startDate: string
  interestType: string
  status: "pending" | "collected"
  notes?: string
  loanDate: string
}

export function LoanEntryForm({ onAddLoan }: { onAddLoan: (loan: Loan) => void }) {
  const [formData, setFormData] = useState({
    borrowerName: "",
    amount: "",
    interestRate: "",
    startDate: "",
    interestType: "",
    notes: "",
    loanDate: new Date().toISOString().split("T")[0],
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, interestType: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const newLoan = {
      ...formData,
      id: Date.now(),
      amount: Number.parseFloat(formData.amount),
      interestRate: Number.parseFloat(formData.interestRate),
      status: "pending",
    }
    onAddLoan(newLoan)
    setFormData({
      borrowerName: "",
      amount: "",
      interestRate: "",
      startDate: "",
      interestType: "",
      notes: "",
      loanDate: new Date().toISOString().split("T")[0],
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-medium">Add New Loan</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            name="borrowerName"
            placeholder="Borrower Name"
            value={formData.borrowerName}
            onChange={handleInputChange}
            required
          />
          <Input
            name="amount"
            type="number"
            placeholder="Loan Amount (NPR)"
            value={formData.amount}
            onChange={handleInputChange}
            required
          />
          <Input
            name="interestRate"
            type="number"
            placeholder="Interest Rate (%)"
            value={formData.interestRate}
            onChange={handleInputChange}
            required
          />
          <Input
            name="startDate"
            type="date"
            placeholder="Start Date"
            value={formData.startDate}
            onChange={handleInputChange}
            required
          />
          <Select onValueChange={handleSelectChange} required>
            <SelectTrigger>
              <SelectValue placeholder="Interest Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="simple">Simple Interest</SelectItem>
              <SelectItem value="compound">Compound Interest</SelectItem>
            </SelectContent>
          </Select>
          <Input
            name="loanDate"
            type="date"
            placeholder="Loan Date"
            value={formData.loanDate}
            onChange={handleInputChange}
            required
          />
          <Textarea
            name="notes"
            placeholder="Notes or Purpose of Money"
            value={formData.notes}
            onChange={handleInputChange}
          />
          <Button type="submit" className="w-full">
            Add Loan
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

